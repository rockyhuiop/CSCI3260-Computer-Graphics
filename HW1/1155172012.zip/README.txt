CSCI3260 Assignment 1 Keyboard & Mouse Events  

 - Name: HUI Rocky		
 - Student ID: 1155172012

Manipulation:
	// Key "Esc": exit
	// Key "W": move the airplane to north
	// Key "S": move the airplane to south
        // Key "A": move the airplane to West
        // Key "D": move the airplane to East
        // Key "Q": make the airplane larger
        // Key "Q": make the airplane smaller
