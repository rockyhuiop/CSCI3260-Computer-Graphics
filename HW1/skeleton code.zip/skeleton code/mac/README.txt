CSCI3260 Assignment 1 Keyboard & Mouse Events  

 - Name: 		
 - Student ID:	

Manipulation:
	// For example:
	// Key "Esc": exit
	// Key "r": rotate the cube
	// ...
