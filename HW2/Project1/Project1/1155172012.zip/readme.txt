CSCI3260 Assignment 2 Texture Mapping/ Lighting Control  

Name: HUI Rocky
Student ID: 1155172012

Manipulation:
	Key "W": brightness of light increase
	Key "S": brightness of light decrease
	Key "UP": Dog move forward
	Key "Down": Dog move backward
	Key "Left": Dog turn to the left
	Key "Right": Dog turn to the Right
	Key "L": Dog random movement in the horizon plane
	Key "1": Change the dog texture to texture1
	Key "2": Change the dog texture to texture2
	Key "3": Change the Ground texture to texture1
	Key "4": Change the Ground texture to texture2
	Mouse (left click and drag upward): whole scene move upward
	Mouse (left click and drag downward): whole scene move downward
	Mouse (left click and drag to the left): whole scene rotate left
	Mouse (left click and drag to the Right): whole scene rotate Right
	Mouse (Scroll forward): whole scene zoom in
	Mouse (Scroll backward): whole scene zoom out

